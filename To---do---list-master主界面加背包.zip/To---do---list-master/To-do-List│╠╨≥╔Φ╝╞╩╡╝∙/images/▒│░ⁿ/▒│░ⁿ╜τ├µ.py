#!/usr/bin/env python
# coding: utf-8

# In[56]:


import pygame
import sys
import traceback
from pygame.locals import *

class Lable(pygame.sprite.Sprite):  #定义my_flower类，为用户自己的花朵初始化相关属性
    def __init__(self , label_image , location):  #location表示不同标签所在位置
        pygame.sprite.Sprite.__init__(self)
        self.label = label_image
        self.label_rect = self.label.get_rect()   #获取图像的限定矩形,即图片的位置
        #修改图片的位置
        self.label_rect.left , self.label_rect.top = location[0] , location[1]
        
pygame.init()   #pygame初始化
#进行背景和标题的设置
bg_size = width , height = 900 , 675   #根据图片尺寸设置背景尺寸
Screen = pygame.display.set_mode(bg_size , 0 , 32)  
pygame.display.set_caption("背包界面")    #设置标题
background2 = pygame.image.load(r"C:\Users\江炳青\Desktop\背包\蓝天白云.png").convert_alpha() #画图 把背包画在左面 人在中间 东西在右边
background1 = pygame.image.load(r"C:\Users\江炳青\Desktop\背包\玄关.png").convert_alpha() #第二个游戏界面的背景

#加载所有图片
#穿戴界面的小男孩
boy_chuandai = pygame.image.load(r"C:\Users\江炳青\Desktop\背包\小男孩_穿戴.png").convert_alpha()
boy_kozhao = pygame.image.load(r"C:\Users\江炳青\Desktop\背包\小男孩_口罩.png").convert_alpha()
boy_shoutao = pygame.image.load(r"C:\Users\江炳青\Desktop\背包\小男孩_手套.png").convert_alpha()
boy_jiujing = pygame.image.load(r"C:\Users\江炳青\Desktop\背包\小男孩_酒精.png").convert_alpha()
boy_kozhao_shoutao = pygame.image.load(r"C:\Users\江炳青\Desktop\背包\小男孩_口罩手套.png").convert_alpha()
boy_kozhao_jiujing = pygame.image.load(r"C:\Users\江炳青\Desktop\背包\小男孩_口罩酒精.png").convert_alpha()
boy_shoutao_jiujing = pygame.image.load(r"C:\Users\江炳青\Desktop\背包\小男孩_手套酒精.png").convert_alpha()
boy_shoutao_kozhao_jiujing = pygame.image.load(r"C:\Users\江炳青\Desktop\背包\小男孩_手套口罩酒精.png").convert_alpha()
###画八个图 根据背包里的东西加载

#穿戴
chuandai_nor = pygame.image.load(r"C:\Users\江炳青\Desktop\背包\穿戴_默认.png").convert_alpha()
chuandai = chuandai_nor
chuandai_click = pygame.image.load(r"C:\Users\江炳青\Desktop\背包\穿戴_点击.png").convert_alpha()

#脱下
tuoxia_nor = pygame.image.load(r"C:\Users\江炳青\Desktop\背包\脱下_默认.png").convert_alpha()
tuoxia= tuoxia_nor
tuoxia_click = pygame.image.load(r"C:\Users\江炳青\Desktop\背包\脱下_点击.png").convert_alpha()

#口罩
kozhao_nor = pygame.image.load(r"C:\Users\江炳青\Desktop\背包\口罩.png").convert_alpha()
kozhao = kozhao_nor
kozhao_click = pygame.image.load(r"C:\Users\江炳青\Desktop\背包\口罩.png").convert_alpha()


#酒精
jiujing_nor = pygame.image.load(r"C:\Users\江炳青\Desktop\背包\酒精.png").convert_alpha()
jiujing = jiujing_nor
jiujing_click = pygame.image.load(r"C:\Users\江炳青\Desktop\背包\酒精.png").convert_alpha()


#手套
shoutao_nor =  pygame.image.load(r"C:\Users\江炳青\Desktop\背包\手套.png").convert_alpha()
shoutao = shoutao_nor
shoutao_click = pygame.image.load(r"C:\Users\江炳青\Desktop\背包\手套.png").convert_alpha()


#返回图标
back_nor = pygame.image.load(r"C:\Users\江炳青\Desktop\背包\返回_默认.png").convert_alpha()
back = back_nor
back_click = pygame.image.load(r"C:\Users\江炳青\Desktop\背包\返回_点击.png").convert_alpha()

#跳转图标
go_nor = pygame.image.load(r"C:\Users\江炳青\Desktop\背包\小背包_默认.png").convert_alpha()
go = go_nor
go_click = pygame.image.load(r"C:\Users\江炳青\Desktop\背包\小背包_点击.png").convert_alpha()



#设置标签位置
location_back = back_left , back_top = 20 , 50
location_go = go_left , go_top = 750, 550
location_chuandai = chuandai_left, chuandai_top = 300, 200
location_tuoxia = tuoxia_left,tuoxia_top = 400, 400

#加载标签对象
label_back = Lable(back_nor ,location_back)
label_go = Lable(go_nor ,location_go)
label_chuandai = Lable(chuandai_nor ,location_chuandai)
label_tuoxia = Lable(tuoxia_nor ,location_tuoxia)

def main(): 
    screen = Screen 
    location_kozhao = kozhao_left , kozhao_top = 550, 250
    location_jiujing = jiujing_left , jiujing_top = 700, 225
    location_shoutao = shoutao_left , shoutao_top = 800, 225
    
    background_control = 0  #默认为主屏幕 
    flag_kozhao = 0 #默认在玄关页面
    flag_shoutao = 0
    flag_jiujing = 0
    flag_chuandai = 0
    flag_tuoxia = 0
    clock = pygame.time.Clock() 
    running = True
    
    while running:
        label_kozhao = Lable(kozhao_nor ,location_kozhao)
        label_jiujing = Lable(jiujing_nor ,location_jiujing)
        label_shoutao = Lable(shoutao_nor ,location_shoutao)
        for event in pygame.event.get():
            if event.type == QUIT:  #用户推出程序
                pygame.quit()
                sys.exit()
            elif event.type == MOUSEBUTTONDOWN:
                if event.button == 1 and label_go.label_rect.collidepoint(event.pos):
                    background_control = 1 #加载穿戴背景
                if event.button == 1 and label_back.label_rect.collidepoint(event.pos):
                    background_control = 0 #加载玄关背景
                    flag_chuandai = 0      #如果用户回到主页面再回来 必须再按下穿戴 这个变量为了不让程序自动给小南嗨穿戴
                
                if event.button == 1 and label_kozhao.label_rect.collidepoint(event.pos):
                    flag_kozhao = 1
                if event.button == 1 and label_shoutao.label_rect.collidepoint(event.pos):
                    flag_shoutao = 1
                if event.button == 1 and label_jiujing.label_rect.collidepoint(event.pos):
                    flag_jiujing = 1
                if event.button == 1 and label_chuandai.label_rect.collidepoint(event.pos):
                    flag_chuandai = 1
                if event.button == 1 and label_tuoxia.label_rect.collidepoint(event.pos):
                    flag_tuoxia = 1
                
            #图标放大           
            elif event.type == MOUSEMOTION:
                if label_kozhao.label_rect.collidepoint(event.pos):
                    kozhao = kozhao_click
                else:
                    kozhao = kozhao_nor   
                if label_jiujing.label_rect.collidepoint(event.pos):
                    jiujing = jiujing_click
                else:
                    jiujing = jiujing_nor
                if label_shoutao.label_rect.collidepoint(event.pos):
                    shoutao = shoutao_click
                else:
                    shoutao = shoutao_nor   
                if label_back.label_rect.collidepoint(event.pos):
                    back = back_click
                else:
                    back = back_nor    
                if label_go.label_rect.collidepoint(event.pos):
                    go = go_click
                else:
                    go = go_nor 
                if label_chuandai.label_rect.collidepoint(event.pos):
                    chuandai = chuandai_click
                else:
                    chuandai = chuandai_nor  
                if label_tuoxia.label_rect.collidepoint(event.pos):
                    tuoxia = tuoxia_click
                else:
                    tuoxia = tuoxia_nor  
         #背包界面
        if background_control == 1:
            screen.blit(background2 , (0 , 0))   #绘制背景，后画的会覆盖先画的
            screen.blit(back , label_back.label_rect) 
            screen.blit(tuoxia, label_tuoxia.label_rect) 
            screen.blit(chuandai, label_chuandai.label_rect) 
            if flag_kozhao == 1:
                 screen.blit(kozhao,(550,250))
            if flag_jiujing == 1:
                 screen.blit(jiujing,(700,225))
            if flag_shoutao == 1:
                 screen.blit(shoutao,(800,225))
                    
    #排列组合所有情况 出现不同小男孩的照片
            if flag_chuandai == 0:
                screen.blit(boy_chuandai , (100,200))
            if flag_chuandai == 1 and flag_kozhao == 0 and flag_shoutao == 0 and flag_jiujing ==0:
                screen.blit(boy_chuandai , (100,200)) #防止一开始没东西就穿戴会出问题
            if flag_chuandai==1 and flag_kozhao == 1 and flag_shoutao == 0 and flag_jiujing ==0: #点击穿戴且背包里有口罩
                screen.blit(boy_kozhao , (100,200))   
            if flag_chuandai==1 and flag_kozhao == 0  and flag_shoutao == 1 and flag_jiujing ==0: #点击穿戴且背包里有口罩
                screen.blit(boy_shoutao , (100,200))
            if flag_chuandai==1 and flag_kozhao == 0 and flag_shoutao == 0 and flag_jiujing ==1: #点击穿戴且背包里有口罩
                screen.blit(boy_jiujing , (100,200))
            if flag_chuandai==1 and flag_kozhao == 1 and flag_shoutao == 1 and flag_jiujing ==0: #点击穿戴且背包里有口罩
                screen.blit(boy_kozhao_shoutao , (100,200))
            if flag_chuandai==1 and flag_kozhao == 1 and flag_shoutao == 0 and flag_jiujing ==1: #点击穿戴且背包里有口罩
                screen.blit(boy_kozhao_jiujing , (100,200))
            if flag_chuandai==1 and flag_kozhao == 0 and flag_shoutao == 1 and flag_jiujing ==1: #点击穿戴且背包里有口罩
                screen.blit(boy_shoutao_jiujing , (100,200))
            if flag_chuandai==1 and flag_kozhao == 1 and flag_shoutao == 1 and flag_jiujing ==1: #点击穿戴且背包里有口罩
                screen.blit(boy_shoutao_kozhao_jiujing , (100,200))
            #一键删除
            if flag_tuoxia == 1:
                screen.blit(boy_chuandai , (100,200))
                #背包里的东西全要消失 回到主界面
                flag_kozhao = 0
                flag_jiujing = 0
                flag_shoutao = 0         

        #玄关界面   
        if background_control == 0:
            screen.blit(background1 , (0 , 0))   #绘制背景，后画的会覆盖先画的
            screen.blit(go,(750, 550))
            screen.blit(kozhao,label_kozhao.label_rect)    #绘制标签
            screen.blit(jiujing,label_jiujing.label_rect)    #绘制标签
            screen.blit(shoutao,label_shoutao.label_rect)    #绘制标签
            if(flag_tuoxia==1):
                flag_tuoxia =0
                
        #图片移走消失
        if flag_kozhao == 1:
            location_kozhao = kozhao_left , kozhao_top = 1000,1000
        else:
            location_kozhao = kozhao_left , kozhao_top = 550, 250
        if flag_jiujing == 1:
            location_jiujing = jiujing_left , jiujing_top = 1000,1000
        else:
            location_jiujing = jiujing_left , jiujing_top = 700, 225
        if flag_shoutao == 1:
            location_shoutao = shoutao_left , shoutao_top = 1000,1000
        else:
            location_shoutao = shoutao_left , shoutao_top = 800, 225
            
            
        pygame.display.flip()   #刷新画面，将内存画布反转到屏幕上
        clock.tick(240)#设定帧率
        
if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        pass
    #except:
     #   traceback.print_exc()
      #  pygame.quit()
       # input()


# In[ ]:





# In[ ]:




